

class Store[State]:
  

  def get_state():